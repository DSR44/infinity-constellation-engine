// ═══════════════════════════════════════════════════════════════
//  INFINITY SHIELD — Fingerprint Spoofers
//  SHA-256 → deterministic selection from plausibility pools
//  Every page load = new identity. Nothing stored. Nothing tracked.
// ═══════════════════════════════════════════════════════════════

const _shieldState = {
  enabled: true,
  identitiesGenerated: 0,
  currentIdentity: null
};

// ─── SHA-256 (synchronous via simple hash for content script) ───
function shieldHash(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  h = h >>> 0;
  let h2 = 0x6c62272e;
  for (let i = str.length - 1; i >= 0; i--) {
    h2 ^= str.charCodeAt(i);
    h2 = Math.imul(h2, 0x5bd1e995);
  }
  h2 = h2 >>> 0;
  return [h, h2, (h ^ h2) >>> 0, (h + h2) >>> 0, Math.imul(h, h2) >>> 0,
          (h ^ (h2 >> 16)) >>> 0, (h2 ^ (h >> 8)) >>> 0, ((h + h2) ^ h) >>> 0];
}

function pickFromPool(pool, seeds, seedIndex) {
  return pool[seeds[seedIndex % seeds.length] % pool.length];
}

// ─── Generate Identity ───
function generateIdentity() {
  const domain = window.location.hostname || "unknown";
  const timestamp = Date.now();
  const pageCount = _shieldState.identitiesGenerated;
  const seed = domain + "|" + timestamp + "|" + pageCount;
  const seeds = shieldHash(seed);

  const identity = {
    userAgent: pickFromPool(SHIELD_POOLS.userAgents, seeds, 0),
    platform: pickFromPool(SHIELD_POOLS.platforms, seeds, 1),
    resolution: pickFromPool(SHIELD_POOLS.resolutions, seeds, 2),
    colorDepth: pickFromPool(SHIELD_POOLS.colorDepths, seeds, 3),
    gpuVendor: pickFromPool(SHIELD_POOLS.gpuVendors, seeds, 4),
    gpuRenderer: pickFromPool(SHIELD_POOLS.gpuRenderers, seeds, 5),
    languages: pickFromPool(SHIELD_POOLS.languages, seeds, 6),
    timezoneOffset: pickFromPool(SHIELD_POOLS.timezoneOffsets, seeds, 7),
    hardwareConcurrency: pickFromPool(SHIELD_POOLS.hardwareConcurrency, seeds, 0),
    deviceMemory: pickFromPool(SHIELD_POOLS.deviceMemory, seeds, 1),
    canvasNoise: (seeds[2] % 255) / 255 * 0.02,
    audioNoise: (seeds[3] % 255) / 255 * 0.0001
  };

  _shieldState.currentIdentity = identity;
  _shieldState.identitiesGenerated++;
  return identity;
}

// ═══════════════════════════════════════════════════════════════
//  SPOOF: Navigator Properties
// ═══════════════════════════════════════════════════════════════

function spoofNavigator(identity) {
  try {
    Object.defineProperty(Navigator.prototype, "userAgent", {
      get: () => identity.userAgent, configurable: true
    });
    Object.defineProperty(Navigator.prototype, "platform", {
      get: () => identity.platform, configurable: true
    });
    Object.defineProperty(Navigator.prototype, "hardwareConcurrency", {
      get: () => identity.hardwareConcurrency, configurable: true
    });
    Object.defineProperty(Navigator.prototype, "deviceMemory", {
      get: () => identity.deviceMemory, configurable: true
    });
    Object.defineProperty(Navigator.prototype, "languages", {
      get: () => Object.freeze(identity.languages), configurable: true
    });
    Object.defineProperty(Navigator.prototype, "language", {
      get: () => identity.languages[0], configurable: true
    });
    Object.defineProperty(Navigator.prototype, "appVersion", {
      get: () => identity.userAgent.replace("Mozilla/", ""), configurable: true
    });
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════════
//  SPOOF: Screen Properties
// ═══════════════════════════════════════════════════════════════

function spoofScreen(identity) {
  const [w, h] = identity.resolution;
  try {
    Object.defineProperty(Screen.prototype, "width", {
      get: () => w, configurable: true
    });
    Object.defineProperty(Screen.prototype, "height", {
      get: () => h, configurable: true
    });
    Object.defineProperty(Screen.prototype, "availWidth", {
      get: () => w, configurable: true
    });
    Object.defineProperty(Screen.prototype, "availHeight", {
      get: () => h - 40, configurable: true
    });
    Object.defineProperty(Screen.prototype, "colorDepth", {
      get: () => identity.colorDepth, configurable: true
    });
    Object.defineProperty(Screen.prototype, "pixelDepth", {
      get: () => identity.colorDepth, configurable: true
    });
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════════
//  SPOOF: Canvas Fingerprint
// ═══════════════════════════════════════════════════════════════

function spoofCanvas(identity) {
  try {
    const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
    CanvasRenderingContext2D.prototype.getImageData = function() {
      const imageData = origGetImageData.apply(this, arguments);
      const noise = identity.canvasNoise;
      const seeds = shieldHash(identity.userAgent);
      for (let i = 0; i < imageData.data.length; i += 4) {
        const shift = ((seeds[i % seeds.length] + i) % 3) - 1;
        imageData.data[i] = Math.max(0, Math.min(255, imageData.data[i] + shift * noise * 255));
        imageData.data[i + 1] = Math.max(0, Math.min(255, imageData.data[i + 1] - shift * noise * 255));
      }
      return imageData;
    };

    const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function() {
      const ctx = this.getContext("2d");
      if (ctx) {
        const seeds = shieldHash(identity.gpuRenderer + Date.now());
        const w = this.width, h = this.height;
        try {
          const img = ctx.getImageData(0, 0, Math.min(w, 16), Math.min(h, 16));
          for (let i = 0; i < img.data.length; i += 4) {
            img.data[i] = (img.data[i] + (seeds[i % seeds.length] % 2)) % 256;
          }
          ctx.putImageData(img, 0, 0);
        } catch(e) {}
      }
      return origToDataURL.apply(this, arguments);
    };
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════════
//  SPOOF: WebGL Fingerprint
// ═══════════════════════════════════════════════════════════════

function spoofWebGL(identity) {
  try {
    const getParamOrig = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(param) {
      const UNMASKED_VENDOR = 0x9245;
      const UNMASKED_RENDERER = 0x9246;
      if (param === UNMASKED_VENDOR) return identity.gpuVendor;
      if (param === UNMASKED_RENDERER) return identity.gpuRenderer;
      return getParamOrig.apply(this, arguments);
    };

    if (typeof WebGL2RenderingContext !== "undefined") {
      const getParam2Orig = WebGL2RenderingContext.prototype.getParameter;
      WebGL2RenderingContext.prototype.getParameter = function(param) {
        const UNMASKED_VENDOR = 0x9245;
        const UNMASKED_RENDERER = 0x9246;
        if (param === UNMASKED_VENDOR) return identity.gpuVendor;
        if (param === UNMASKED_RENDERER) return identity.gpuRenderer;
        return getParam2Orig.apply(this, arguments);
      };
    }
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════════
//  SPOOF: AudioContext Fingerprint
// ═══════════════════════════════════════════════════════════════

function spoofAudio(identity) {
  try {
    const origCreateOscillator = AudioContext.prototype.createOscillator;
    AudioContext.prototype.createOscillator = function() {
      const osc = origCreateOscillator.apply(this, arguments);
      const origConnect = osc.connect.bind(osc);
      osc.connect = function(dest) {
        if (dest instanceof AnalyserNode) {
          const origGetFloat = dest.getFloatFrequencyData.bind(dest);
          dest.getFloatFrequencyData = function(array) {
            origGetFloat(array);
            const seeds = shieldHash(identity.gpuRenderer);
            for (let i = 0; i < array.length; i++) {
              array[i] += (seeds[i % seeds.length] % 100 - 50) * identity.audioNoise;
            }
          };
        }
        return origConnect(dest);
      };
      return osc;
    };

    if (typeof OfflineAudioContext !== "undefined") {
      const origRender = OfflineAudioContext.prototype.startRendering;
      OfflineAudioContext.prototype.startRendering = function() {
        return origRender.apply(this, arguments).then(buffer => {
          const channelData = buffer.getChannelData(0);
          const seeds = shieldHash(identity.userAgent + identity.gpuRenderer);
          for (let i = 0; i < channelData.length; i++) {
            channelData[i] += (seeds[i % seeds.length] % 100 - 50) * identity.audioNoise;
          }
          return buffer;
        });
      };
    }
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════════
//  SPOOF: Timezone
// ═══════════════════════════════════════════════════════════════

function spoofTimezone(identity) {
  try {
    const origGetTimezoneOffset = Date.prototype.getTimezoneOffset;
    Date.prototype.getTimezoneOffset = function() {
      return identity.timezoneOffset;
    };
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════════
//  ACTIVATE SHIELD
// ═══════════════════════════════════════════════════════════════

function activateShield() {
  if (!_shieldState.enabled) return;

  const identity = generateIdentity();

  spoofNavigator(identity);
  spoofScreen(identity);
  spoofCanvas(identity);
  spoofWebGL(identity);
  spoofAudio(identity);
  spoofTimezone(identity);
}

activateShield();
