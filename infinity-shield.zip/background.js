chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    shieldEnabled: true,
    totalIdentities: 0,
    installedAt: new Date().toISOString()
  });
});
