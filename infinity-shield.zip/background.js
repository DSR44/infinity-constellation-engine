// Infinity Shield — background
// WebRTC IP handling: block non-proxied UDP so local/public IP can't leak past VPN

const WEBRTC_LOCKED = "disable_non_proxied_udp";
const WEBRTC_DEFAULT = "default";

function setWebRTCPolicy(enabled) {
  if (!chrome.privacy || !chrome.privacy.network || !chrome.privacy.network.webRTCIPHandlingPolicy) {
    return;
  }
  const value = enabled ? WEBRTC_LOCKED : WEBRTC_DEFAULT;
  chrome.privacy.network.webRTCIPHandlingPolicy.set(
    { value },
    () => {
      if (chrome.runtime.lastError) {
        console.warn(
          "[Infinity Shield] WebRTC policy:",
          chrome.runtime.lastError.message
        );
      }
    }
  );
}

function applyShieldNetwork(enabled) {
  setWebRTCPolicy(enabled !== false);
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set(
    {
      shieldEnabled: true,
      totalIdentities: 0,
      installedAt: new Date().toISOString()
    },
    () => applyShieldNetwork(true)
  );
});

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(["shieldEnabled"], (data) => {
    applyShieldNetwork(data.shieldEnabled !== false);
  });
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes.shieldEnabled) return;
  applyShieldNetwork(changes.shieldEnabled.newValue !== false);
});

// Apply on service worker wake
chrome.storage.local.get(["shieldEnabled"], (data) => {
  applyShieldNetwork(data.shieldEnabled !== false);
});
