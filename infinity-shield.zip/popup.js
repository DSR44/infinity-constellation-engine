const PREVIEW_UAS = [
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0",
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/17.4",
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124.0",
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0"
];
const PREVIEW_RES = ["1920x1080","2560x1440","1366x768","1440x900","3840x2160"];
const PREVIEW_GPU = ["NVIDIA RTX 3080","Intel UHD 630","AMD RX 6800 XT","Apple M1 Pro","NVIDIA GTX 1660 Ti"];

function toggleShield() {
  const toggle = document.getElementById('shield-toggle');
  const isOn = toggle.classList.contains('on');
  toggle.classList.toggle('on');
  chrome.storage.local.set({ shieldEnabled: !isOn });
}

function showIdentityPreview(domain) {
  const ts = Date.now();
  const seed = domain + '|' + ts;
  let h = 0x811c9dc5;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  h = h >>> 0;

  const ua = PREVIEW_UAS[h % PREVIEW_UAS.length];
  const res = PREVIEW_RES[h % PREVIEW_RES.length];
  const gpu = PREVIEW_GPU[h % PREVIEW_GPU.length];

  document.getElementById('identity-info').innerHTML =
    '<span>UA:</span> ' + ua.substring(0, 50) + '...<br>' +
    '<span>Screen:</span> ' + res + '<br>' +
    '<span>GPU:</span> ' + gpu;
}

function loadStats() {
  chrome.storage.local.get(
    ["shieldEnabled", "totalIdentities", "installedAt"],
    (data) => {
      const toggle = document.getElementById('shield-toggle');
      if (data.shieldEnabled === false) {
        toggle.classList.remove('on');
      } else {
        toggle.classList.add('on');
      }

      document.getElementById('total-count').textContent =
        (data.totalIdentities || 0).toLocaleString();

      if (data.installedAt) {
        const d = new Date(data.installedAt);
        document.getElementById('installed-date').textContent =
          d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      }
    }
  );

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url) {
      try {
        const url = new URL(tabs[0].url);
        document.getElementById('current-domain').textContent = url.hostname;
        showIdentityPreview(url.hostname);
      } catch(e) {
        document.getElementById('current-domain').textContent = '---';
      }
    }
  });
}

document.getElementById('shield-toggle').addEventListener('click', toggleShield);
loadStats();
