(function() {
  try {
    const inject = (src) => {
      const s = document.createElement("script");
      s.src = chrome.runtime.getURL(src);
      s.onload = () => s.remove();
      (document.documentElement || document.head).prepend(s);
    };
    inject("pools/data.js");
    inject("spoofers/all.js");
  } catch(e) {}

  try {
    chrome.storage.local.get(["totalIdentities", "shieldEnabled"], (data) => {
      if (data.shieldEnabled === false) return;
      const total = (data.totalIdentities || 0) + 1;
      chrome.storage.local.set({ totalIdentities: total });
    });
  } catch(e) {}
})();
