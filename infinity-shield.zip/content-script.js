// Runs in ISOLATED world — has chrome.storage access
// Spoofers run in MAIN world — have page DOM access
// This script only tracks the identity counter for the popup
try {
  chrome.storage.local.get(["totalIdentities"], (data) => {
    const total = (data.totalIdentities || 0) + 1;
    chrome.storage.local.set({ totalIdentities: total });
  });
} catch(e) {}
